function navigate(sectionId) {
  document.querySelectorAll("main > section").forEach((section) => {
    section.style.display = "none";
  });
  document.getElementById(sectionId).style.display = "block";
}

document.addEventListener("DOMContentLoaded", () => {
  navigate("dashboard"); // tampilkan halaman awal
});

function addVehicle() {
  alert("Fitur tambah kendaraan belum tersedia.");
}

function addVehicle() {
  alert("Fitur tambah kendaraan belum tersedia.");
}

function loadMoreTips() {
  alert("Konten tambahan akan ditampilkan di sini (fitur belum tersedia).");
}

function showBookingDetail() {
  alert("Detail servis akan ditampilkan di sini (fitur belum tersedia).");
}
