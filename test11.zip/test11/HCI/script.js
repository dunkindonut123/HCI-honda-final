document.addEventListener('DOMContentLoaded', () => {
    // --- App State & Mock Data ---
    let currentUser = null; 
    let vehicles = []; // Stores { id, userId, name, license, engineNo, year, km, series, image, stnkExpiry }
    let serviceHistory = []; // Stores { id, vehicleId, vehicleName, license, date, time, type, location, kmAtService, status, cost, invoice, mechanic, bookingType }
    const tips = [ 
         { 
            id: 1, 
            title: 'Cara Mengganti Oli Mesin Mobil Anda', 
            image: 'oli.png', // Relative path
            snippet: 'Penggantian oli mesin adalah salah satu aspek krusial dalam perawatan mobil yang sering terabaikan. Oli berfungsi sebagai pelumas...',
            content: 'Mengganti oli mesin secara teratur adalah kunci untuk menjaga performa mesin mobil Anda tetap optimal dan memperpanjang umurnya. Oli melumasi komponen bergerak, mengurangi gesekan, membersihkan kotoran, dan membantu mendinginkan mesin. <br><br><strong>Langkah-langkah Umum:</strong><br>1. Siapkan peralatan: oli baru sesuai spesifikasi mobil, filter oli baru, kunci filter oli, kunci pas/socket untuk baut pembuangan, wadah penampung oli bekas, corong, lap bersih, dan dongkrak serta jack stand (jika diperlukan).<br>2. Panaskan mesin mobil selama beberapa menit agar oli lebih encer dan mudah mengalir.<br>3. Posisikan mobil di tempat yang datar dan aman. Jika perlu, gunakan dongkrak dan jack stand untuk mengangkat bagian depan mobil.<br>4. Letakkan wadah penampung di bawah baut pembuangan oli. Buka baut pembuangan dengan hati-hati (oli mungkin panas) dan biarkan oli bekas mengalir keluar sepenuhnya.<br>5. Setelah oli habis, bersihkan area sekitar baut dan pasang kembali baut pembuangan dengan torsi yang sesuai.<br>6. Lepaskan filter oli lama menggunakan kunci filter. Pastikan gasket karet filter lama tidak tertinggal di blok mesin.<br>7. Oleskan sedikit oli baru pada gasket filter oli yang baru, lalu pasang filter baru dengan tangan hingga kencang, kemudian putar sekitar 3/4 putaran lagi (ikuti petunjuk pada filter atau manual mobil).<br>8. Buka tutup pengisian oli di atas mesin dan tuangkan oli baru sesuai dengan kapasitas yang direkomendasikan pabrikan. Gunakan corong agar tidak tumpah.<br>9. Pasang kembali tutup pengisian oli. Nyalakan mesin selama beberapa menit, lalu matikan dan tunggu beberapa saat agar oli turun.<br>10. Periksa level oli menggunakan dipstick dan tambahkan jika kurang. Periksa juga apakah ada kebocoran di sekitar baut pembuangan dan filter oli.<br>11. Buang oli bekas dan filter bekas dengan benar di tempat penampungan limbah B3 atau bengkel yang menerima oli bekas.<br><br>Selalu konsultasikan buku manual kendaraan Anda untuk instruksi spesifik dan jenis oli yang direkomendasikan.' 
        },
        { 
            id: 2, 
            title: 'Tips Penting Merawat Ban Mobil Agar Awet', 
            image: 'ban.jpg', // Relative path
            snippet: 'Ban adalah satu-satunya komponen mobil yang bersentuhan langsung dengan jalan. Perawatan ban yang baik sangat penting untuk...',
            content: 'Merawat ban mobil dengan baik tidak hanya memperpanjang usia pakai ban itu sendiri tetapi juga meningkatkan keselamatan dan efisiensi bahan bakar.<br><br><strong>Berikut beberapa tipsnya:</strong><br>1. <strong>Periksa Tekanan Angin Secara Berkala:</strong> Tekanan angin yang tidak sesuai (kurang atau berlebih) dapat menyebabkan ban cepat aus, handling tidak stabil, dan boros bahan bakar. Periksa tekanan minimal sebulan sekali saat ban dalam kondisi dingin, sesuai rekomendasi pabrikan yang tertera di stiker pilar pintu pengemudi atau buku manual.<br>2. <strong>Lakukan Rotasi Ban:</strong> Rotasi ban secara teratur (biasanya setiap 8.000-10.000 km) membantu agar keausan ban lebih merata, karena pola keausan ban depan dan belakang biasanya berbeda.<br>3. <strong>Periksa Keseimbangan (Balancing):</strong> Jika Anda merasakan getaran pada setir saat kecepatan tertentu, kemungkinan ban perlu di-balancing. Balancing memastikan berat terdistribusi merata pada setiap roda.<br>4. <strong>Lakukan Spooring:</strong> Jika mobil terasa menarik ke satu sisi saat berjalan lurus atau kemudi tidak lurus saat mobil lurus, segera lakukan spooring (wheel alignment). Spooring menjaga sudut kelurusan roda sesuai standar pabrikan, mencegah keausan ban yang tidak merata dan menjaga stabilitas kemudi.<br>5. <strong>Periksa Kondisi Fisik Ban:</strong> Secara visual, periksa apakah ada benjolan, sobekan, retakan, atau benda asing yang menancap pada ban. Periksa juga kedalaman alur ban (Tread Wear Indicator/TWI). Jika sudah mencapai batas TWI, ban harus segera diganti.<br>6. <strong>Hindari Membawa Beban Berlebih:</strong> Beban yang melebihi kapasitas maksimal kendaraan akan memberi tekanan ekstra pada ban dan mempercepat keausannya.<br>7. <strong>Gaya Mengemudi:</strong> Hindari akselerasi dan pengereman mendadak, serta menikung dengan kecepatan tinggi, karena hal ini dapat mempercepat keausan ban.'
        },
        { 
            id: 3, 
            title: 'Kenali Tanda-Tanda Rem Mobil Bermasalah', 
            image: 'rem.webp', // Relative path
            snippet: 'Sistem pengereman adalah fitur keselamatan paling vital pada mobil Anda. Mengenali tanda-tanda awal masalah rem dapat mencegah...',
            content: 'Sistem pengereman yang berfungsi optimal adalah hal mutlak untuk keselamatan berkendara. Jangan abaikan tanda-tanda berikut yang mengindikasikan rem mobil Anda mungkin bermasalah:<br><br>1. <strong>Suara Berdecit atau Menggerinda:</strong> Suara melengking saat mengerem biasanya menandakan kampas rem sudah tipis dan perlu diganti. Suara menggerinda bisa berarti kampas rem sudah habis total dan logam bertemu logam, yang bisa merusak piringan cakram atau tromol.<br>2. <strong>Pedal Rem Terasa Dalam atau Empuk:</strong> Jika pedal rem harus diinjak lebih dalam dari biasanya untuk menghentikan mobil, atau terasa empuk (spongy), ini bisa menandakan adanya udara dalam sistem hidrolik, kebocoran minyak rem, atau masalah pada master silinder.<br>3. <strong>Pedal Rem Keras dan Jarak Pengereman Panjang:</strong> Jika pedal rem terasa keras saat diinjak dan mobil butuh jarak lebih jauh untuk berhenti, ini bisa disebabkan oleh masalah pada booster rem atau kampas rem yang terkontaminasi.<br>4. <strong>Getaran pada Pedal Rem atau Setir Saat Mengerem:</strong> Getaran (juddering) saat mengerem seringkali disebabkan oleh piringan cakram (rotor) yang bengkok atau tidak rata. Ini memerlukan pembubutan atau penggantian piringan cakram.<br>5. <strong>Mobil Menarik ke Satu Sisi Saat Mengerem:</strong> Jika mobil cenderung menarik ke kiri atau kanan saat Anda mengerem, ini bisa disebabkan oleh kaliper rem yang macet, selang rem tersumbat, atau kampas rem yang aus tidak merata pada satu sisi.<br>6. <strong>Lampu Indikator Rem Menyala:</strong> Lampu indikator rem pada dashboard yang menyala bisa menandakan berbagai masalah, mulai dari level minyak rem yang rendah, switch rem tangan yang bermasalah, hingga masalah pada sistem ABS (Anti-lock Braking System).<br>7. <strong>Bau Terbakar Setelah Berkendara Agresif:</strong> Jika Anda mencium bau seperti kampas terbakar setelah penggunaan rem secara intensif (misalnya saat turunan panjang), ini bisa menandakan rem terlalu panas (overheating). Berikan waktu bagi rem untuk mendingin.<br><br>Jika Anda mengalami salah satu dari tanda-tanda di atas, segera periksakan sistem pengereman mobil Anda ke bengkel terpercaya untuk diagnosis dan perbaikan yang tepat.'
        },
    ];


    // --- DOM Elements ---
    const pageContentContainer = document.getElementById('page-content-container');
    const appHeaderTitleEl = document.getElementById('appHeaderTitle');
    const backButtonEl = document.getElementById('backButton');
    const headerActionButtonEl = document.getElementById('headerActionButton');
    const navItems = document.querySelectorAll('.bottom-nav .nav-item');

    // --- Page Loading & Navigation State ---
    let pageHistoryStack = [];
    let currentVehicleForBooking = null;
    let currentVehicleForHistoryDetail = null;
    let currentVehicleForViewingDetail = null;
    let currentMyVehiclesFlow = 'booking'; 

    // --- Core Navigation Function ---
    function loadPage(pageIdToLoad, title, context = {}, isBack = false) {
        const template = document.getElementById(pageIdToLoad + "-template");
        if (!template) {
            console.error("Template not found for pageId:", pageIdToLoad);
            pageContentContainer.innerHTML = `<div class="page-padding text-center" style="color: red;">Error: Page template not found.</div>`;
            return;
        }
        pageContentContainer.innerHTML = template.innerHTML;

        if (!isBack) {
             if (pageHistoryStack.length === 0 || pageHistoryStack[pageHistoryStack.length - 1].pageId !== pageIdToLoad || JSON.stringify(pageHistoryStack[pageHistoryStack.length - 1].context) !== JSON.stringify(context) ) {
                pageHistoryStack.push({ pageId: pageIdToLoad, title, context });
            }
        }
        
        updateHeader(title, pageIdToLoad, context);
        updateBottomNavActiveState(pageIdToLoad);
        window.scrollTo(0, 0);
        initializePageContent(pageIdToLoad, context);
    }

    function updateHeader(title, pageId, context) {
        appHeaderTitleEl.textContent = title;
        if (pageId === 'home' || pageId === 'signup-success') {
            backButtonEl.style.visibility = 'hidden';
        } else if (pageHistoryStack.length > 1 || (pageId === 'signup' && pageHistoryStack.length <=1) ) { 
            backButtonEl.style.visibility = 'visible';
        } else {
            backButtonEl.style.visibility = 'hidden';
        }

        headerActionButtonEl.style.visibility = 'hidden';
        headerActionButtonEl.innerHTML = '';
        headerActionButtonEl.onclick = null;

        if (pageId === 'home' && !currentUser) {
            headerActionButtonEl.innerHTML = 'Sign Up';
            headerActionButtonEl.style.visibility = 'visible';
            headerActionButtonEl.onclick = () => loadPage('signup', 'Profil');
        }
    }
    
    function updateBottomNavActiveState(currentPageId) {
        navItems.forEach(item => {
            const itemPageId = item.dataset.pageIdToLoad;
            item.classList.toggle('active', itemPageId === currentPageId ||
                (currentPageId === 'activity' && itemPageId === 'activity') ||
                ((currentPageId === 'signup' || currentPageId === 'profile' || currentPageId === 'signup-success') && itemPageId === 'profile') );
        });
    }

    backButtonEl.addEventListener('click', () => {
        if (pageHistoryStack.length > 1) {
            pageHistoryStack.pop(); 
            const previous = pageHistoryStack[pageHistoryStack.length -1];
            loadPage(previous.pageId, previous.title, previous.context, true);
        } else if (pageHistoryStack.length === 1 && pageHistoryStack[0].pageId !== 'home') {
            pageHistoryStack.pop();
            loadPage('home', 'Beranda', {}, true);
        }
    });

    navItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const pageIdToLoad = item.dataset.pageIdToLoad;
            const title = item.dataset.title;
            let context = { initialTab: item.dataset.initialTab };

            if (pageIdToLoad === 'profile') {
                loadPage(currentUser ? 'profile' : 'signup', 'Profil', context);
            } else if (pageIdToLoad) {
                loadPage(pageIdToLoad, title, context);
            }
        });
    });
    
    document.getElementById('navCenterButton').addEventListener('click', () => {
        if (currentUser) {
            currentMyVehiclesFlow = 'booking';
            loadPage('my-vehicles', 'Kendaraan Saya', { flow: 'booking' });
        } else {
            loadPage('signup', 'Profil');
        }
    });

    function initializePageContent(pageId, context) {
        switch (pageId) {
            case 'home': bindHomeEventListeners(); break;
            case 'signup': bindSignupForm(); break;
            case 'signup-success': bindStatusDoneButton(); break; 
            case 'profile': renderProfileDetails(); bindLogoutButton(); break;
            case 'my-vehicles': currentMyVehiclesFlow = context.flow || 'booking'; renderMyVehiclesPage(); bindMyVehiclesEventListeners(); break;
            case 'add-vehicle': bindAddVehicleForm(); break;
            case 'vehicle-detail': renderVehicleDetailPage(currentVehicleForViewingDetail); break;
            case 'book-service-form': renderBookServiceFormPage(currentVehicleForBooking); bindBookServiceForm(); break;
            case 'activity': renderActivityPage(context.initialTab || 'proses'); break;
            case 'service-history-detail': renderServiceHistoryDetailPage(currentVehicleForHistoryDetail, context.initialTab || 'selesai'); break;
            case 'status-booking-success': case 'status-booking-cancel': bindStatusDoneButton(); break;
            case 'info-tips': renderInfoTipsPage(); break; 
        }
    }

    function bindHomeEventListeners() {
        document.querySelectorAll('.home-icon-grid-item').forEach(item => {
            item.onclick = () => { 
                const pageId = item.dataset.pageIdToLoad;
                const title = item.dataset.title;
                let context = { flow: item.dataset.flow, initialTab: item.dataset.initialTab };
                 if ((pageId === 'my-vehicles' || pageId === 'activity') && !currentUser) {
                    showCustomAlert("Silakan Sign Up atau Login terlebih dahulu untuk mengakses fitur ini.");
                    loadPage('signup', 'Profil');
                    return;
                }
                loadPage(pageId, title, context);
            };
        });
    }
    
    function bindSignupForm() {
        const signupForm = document.getElementById('signupForm');
        if (signupForm) {
            signupForm.onsubmit = (e) => {
                e.preventDefault();
                const name = document.getElementById('signupName').value;
                const email = document.getElementById('signupEmail').value;
                const password = document.getElementById('signupPassword').value;
                const confirmPassword = document.getElementById('signupConfirmPassword').value;
                if (!name || !email || !password) { showCustomAlert("Semua field wajib diisi."); return; }
                if (password !== confirmPassword) { showCustomAlert("Password tidak cocok!"); return; }
                
                currentUser = { id: Date.now(), name, email };
                vehicles = []; 
                serviceHistory = []; 
                
                loadPage('signup-success', 'Pendaftaran Berhasil'); 
            };
        }
    }

    function renderProfileDetails() {
        if (currentUser) {
            const profileUserNameEl = document.getElementById('profileUserName');
            const profileUserEmailEl = document.getElementById('profileUserEmail');
            const displayProfileNameEl = document.getElementById('displayProfileName');
            const displayProfileEmailEl = document.getElementById('displayProfileEmail');

            if(profileUserNameEl) profileUserNameEl.textContent = currentUser.name;
            if(profileUserEmailEl) profileUserEmailEl.textContent = currentUser.email;
            if(displayProfileNameEl) displayProfileNameEl.textContent = currentUser.name;
            if(displayProfileEmailEl) displayProfileEmailEl.textContent = currentUser.email;
        } else { 
            loadPage('signup', 'Profil'); 
        }
    }
    function bindLogoutButton() {
        const logoutButton = document.getElementById('logoutButton');
        if (logoutButton) {
            logoutButton.onclick = () => {
                currentUser = null; 
                pageHistoryStack = []; 
                loadPage('home', 'Beranda');
                showCustomAlert('Anda telah logout.', 'info');
            };
        }
    }
    
    function renderMyVehiclesPage() {
        const container = document.getElementById('myVehiclesListContainer');
        const noVehiclesMsg = document.getElementById('noVehiclesMessage');
        if (!container || !noVehiclesMsg) return; 
        container.innerHTML = ''; 

        const userVehicles = currentUser ? vehicles.filter(v => v.userId === currentUser.id) : [];

        if (userVehicles.length === 0) {
            noVehiclesMsg.style.display = 'block';
        } else {
            noVehiclesMsg.style.display = 'none';
            userVehicles.forEach(vehicle => {
                const card = document.createElement('div'); card.className = 'vehicle-card';
                card.innerHTML = `<img src="${vehicle.image}" alt="${vehicle.name}" onerror="this.src='https://placehold.co/72x48/A93C3C/FFFFFF?text=Mobil'"><div class="vehicle-card-info"><h4>${vehicle.name}</h4><p>${vehicle.license} - ${vehicle.series || vehicle.name.split(' ')[0]}</p></div><div class="vehicle-card-arrow"><i class="fas fa-chevron-right"></i></div>`;
                card.onclick = () => {
                    if (currentMyVehiclesFlow === 'booking') {
                        currentVehicleForBooking = vehicle; loadPage('book-service-form', 'Detail Servis');
                    } else { currentVehicleForViewingDetail = vehicle; loadPage('vehicle-detail', 'Detail Kendaraan'); }
                };
                container.appendChild(card);
            });
        }
    }
    function bindMyVehiclesEventListeners() {
        const addVehicleFab = document.getElementById('addVehicleFab');
        if (addVehicleFab) {
            addVehicleFab.onclick = () => {
                if (!currentUser) { showCustomAlert("Silakan login untuk menambah kendaraan."); loadPage('signup', 'Profil'); return; }
                loadPage(addVehicleFab.dataset.pageIdToLoad, addVehicleFab.dataset.title);
            }
        }
    }

    function bindAddVehicleForm() {
        const addVehicleForm = document.getElementById('addVehicleForm');
        if (addVehicleForm) {
            addVehicleForm.onsubmit = (e) => {
                e.preventDefault();
                if (!currentUser) { showCustomAlert("Silakan login terlebih dahulu."); return; }
                const modelName = document.getElementById('vehicleModelName').value;
                const newVehicle = {
                    id: Date.now(), userId: currentUser.id,
                    name: modelName, license: document.getElementById('vehicleLicensePlate').value,
                    engineNo: document.getElementById('vehicleEngineNo').value, year: document.getElementById('vehicleYear').value,
                    km: document.getElementById('vehicleKM').value, series: modelName.split(' ')[0], 
                    image: `https://placehold.co/120x72/A93C3C/FFFFFF?text=${encodeURIComponent(modelName.split(' ')[0] || 'Mobil')}`
                };
                if (!newVehicle.name || !newVehicle.license || !newVehicle.engineNo || !newVehicle.year || !newVehicle.km) { showCustomAlert("Semua field wajib diisi."); return; }
                vehicles.push(newVehicle);
                showCustomAlert('Kendaraan berhasil ditambahkan!', 'success');
                loadPage('my-vehicles', 'Kendaraan Saya', { flow: currentMyVehiclesFlow });
            };
        }
    }
    
    function renderVehicleDetailPage(vehicle) {
        if (!vehicle) { loadPage('my-vehicles', 'Kendaraan Saya', {flow: 'viewing'}); return; } 
        const vehicleDetailImageEl = document.getElementById('vehicleDetailImage');
        if(vehicleDetailImageEl) {
            vehicleDetailImageEl.src = vehicle.image || 'https://placehold.co/120x72/A93C3C/FFFFFF?text=Mobil';
            vehicleDetailImageEl.onerror = () => { vehicleDetailImageEl.src = 'https://placehold.co/120x72/A93C3C/FFFFFF?text=Mobil'; };
        }
        const elIds = ['vehicleDetailName', 'vehicleDetailEngineNo', 'vehicleDetailYear', 'vehicleDetailSeries', 'vehicleDetailKM', 'vehicleDetailLicense', 'vehicleDetailSTNK'];
        const dataKeys = ['name', 'engineNo', 'year', 'series', 'km', 'license', 'stnkExpiry'];
        elIds.forEach((id, index) => {
            const el = document.getElementById(id);
            if (el) el.textContent = vehicle[dataKeys[index]] || (dataKeys[index] === 'series' ? vehicle.name.split(' ')[0] : '-');
        });
    }

    function renderBookServiceFormPage(vehicle) {
        if (!vehicle) { loadPage('my-vehicles', 'Kendaraan Saya', {flow: 'booking'}); return; }
        const bookingFormVehicleNameEl = document.getElementById('bookingFormVehicleName');
        if(bookingFormVehicleNameEl) bookingFormVehicleNameEl.textContent = vehicle.name;
        
        const kmInput = document.getElementById('bookingKM'); 
        if(kmInput) kmInput.value = vehicle.km;
        
        const dateInput = document.getElementById('bookingDate');
        if (dateInput) { 
            const today = new Date();
            const yyyy = today.getFullYear();
            const mm = String(today.getMonth() + 1).padStart(2, '0'); 
            const dd = String(today.getDate()).padStart(2, '0');
            dateInput.setAttribute('min', `${yyyy}-${mm}-${dd}`); 
        }
    }
    function bindBookServiceForm() {
        const bookServiceForm = document.getElementById('bookServiceForm');
        if (bookServiceForm) {
            bookServiceForm.onsubmit = (e) => {
                e.preventDefault();
                if (!currentUser || !currentVehicleForBooking) { showCustomAlert("Error: User atau kendaraan tidak terpilih."); return; }
                const newBooking = {
                    id: Date.now(), vehicleId: currentVehicleForBooking.id, vehicleName: currentVehicleForBooking.name, license: currentVehicleForBooking.license,
                    date: document.getElementById('bookingDate').value, time: document.getElementById('bookingTime').value,
                    type: document.getElementById('bookingServiceType').value, location: document.getElementById('bookingLocation').value,
                    kmAtService: document.getElementById('bookingKM').value, status: 'Booked', cost: 'Akan dikonfirmasi', invoice: 'N/A', mechanic: 'N/A', bookingType: 'Bengkel'
                };
                if (!newBooking.date || !newBooking.time || !newBooking.type || !newBooking.location || !newBooking.kmAtService) { showCustomAlert("Semua field wajib diisi."); return; }
                serviceHistory.unshift(newBooking);
                showCustomAlert('Servis berhasil dipesan!', 'success');
                loadPage('status-booking-success', 'Status');
            };
        }
    }

    function renderActivityPage(initialTab = 'proses') {
        const prosesContent = document.getElementById('prosesContent');
        const riwayatContent = document.getElementById('riwayatContent');
        
        if (!currentUser) {
            const loginMsg = '<p class="text-center p-4" style="color: #6B7280; margin-top: 1rem;">Silakan login untuk melihat aktivitas.</p>';
            if(prosesContent) prosesContent.innerHTML = loginMsg;
            if(riwayatContent) riwayatContent.innerHTML = loginMsg;
            return;
        }

        document.querySelectorAll('#page-content-container .tab-button').forEach(button => {
            button.onclick = () => { 
                document.querySelectorAll('#page-content-container .tab-button').forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                document.querySelectorAll('#page-content-container .tab-content-item').forEach(content => content.classList.add('hidden'));
                const targetContent = document.getElementById(button.dataset.tabTarget);
                if (targetContent) targetContent.classList.remove('hidden');
            };
        });
        
        // Setup "Dalam Proses" tab
        if(prosesContent) {
            prosesContent.innerHTML = '<p class="text-center no-proses-message" style="display:none; color: #6B7280; margin-top: 1rem;">Tidak ada servis dalam proses.</p>';
            const inProgressServices = serviceHistory.filter(s => s.status === 'Booked' && vehicles.some(v => v.id === s.vehicleId && v.userId === currentUser.id));
            const noProsesMsg = prosesContent.querySelector('.no-proses-message');
            if (inProgressServices.length === 0) { if(noProsesMsg) noProsesMsg.style.display = 'block'; }
            else { 
                if(noProsesMsg) noProsesMsg.style.display = 'none'; 
                inProgressServices.forEach(service => prosesContent.appendChild(createServiceCardDOM(service, true))); 
            }
        }

        // Setup "Riwayat Servis" tab
        if(riwayatContent) {
            riwayatContent.innerHTML = '<p class="text-center no-riwayat-message" style="display:none; color: #6B7280; margin-top: 1rem;">Belum ada riwayat servis.</p>';
            const userVehiclesWithHistory = vehicles.filter(v => v.userId === currentUser.id && serviceHistory.some(s => s.vehicleId === v.id && (s.status === 'Selesai' || s.status === 'Batal')));
            const noRiwayatMsg = riwayatContent.querySelector('.no-riwayat-message');
            if (userVehiclesWithHistory.length === 0) { if(noRiwayatMsg) noRiwayatMsg.style.display = 'block'; }
            else {
                if(noRiwayatMsg) noRiwayatMsg.style.display = 'none';
                userVehiclesWithHistory.forEach(vehicle => {
                    const card = document.createElement('div'); card.className = 'vehicle-card';
                    card.innerHTML = `<img src="${vehicle.image}" alt="${vehicle.name}" onerror="this.src='https://placehold.co/72x48/A93C3C/FFFFFF?text=Mobil'"><div class="vehicle-card-info"><h4>${vehicle.name}</h4> <p>${vehicle.license}</p></div><div class="vehicle-card-arrow"><i class="fas fa-chevron-right"></i></div>`;
                    card.onclick = () => { currentVehicleForHistoryDetail = vehicle; loadPage('service-history-detail', 'Histori Mobil', { initialTab: 'selesai' }); };
                    riwayatContent.appendChild(card);
                });
            }
        }

        const tabButtonToActivate = document.querySelector(`#page-content-container .tab-button[data-tab-target="${initialTab}Content"]`);
        if (tabButtonToActivate) tabButtonToActivate.click(); 
        else {  const firstTabButton = document.querySelector('#page-content-container .tab-button'); if(firstTabButton) firstTabButton.click(); }
    }
    
    function renderServiceHistoryDetailPage(vehicle, initialTab = 'selesai') {
        if (!vehicle) { loadPage('activity', 'Aktivitas Saya'); return; } 
        const historyDetailVehicleNameEl = document.getElementById('historyDetailVehicleName');
        if(historyDetailVehicleNameEl) historyDetailVehicleNameEl.textContent = vehicle.name;
        const historyDetailVehicleLicenseEl = document.getElementById('historyDetailVehicleLicense');
        if(historyDetailVehicleLicenseEl) historyDetailVehicleLicenseEl.textContent = vehicle.license;

        const selesaiContent = document.getElementById('selesaiHistoryContent');
        const batalContent = document.getElementById('batalHistoryContent');

        document.querySelectorAll('#page-content-container .tab-button').forEach(button => {
            button.onclick = () => { 
                document.querySelectorAll('#page-content-container .tab-button').forEach(btn => btn.classList.remove('active'));
                button.classList.add('active');
                document.querySelectorAll('#page-content-container .tab-content-item').forEach(content => content.classList.add('hidden'));
                const targetContent = document.getElementById(button.dataset.tabTarget);
                if(targetContent) targetContent.classList.remove('hidden');
            };
        });

        if(selesaiContent) {
            selesaiContent.innerHTML = '<p class="text-center no-selesai-history" style="display:none; color: #6B7280; margin-top: 1rem;">Tidak ada riwayat servis selesai.</p>';
            const completedServices = serviceHistory.filter(s => s.vehicleId === vehicle.id && s.status === 'Selesai');
            const noSelesaiMsg = selesaiContent.querySelector('.no-selesai-history');
            if (completedServices.length === 0) { if(noSelesaiMsg) noSelesaiMsg.style.display = 'block'; }
            else { if(noSelesaiMsg) noSelesaiMsg.style.display = 'none'; completedServices.forEach(service => selesaiContent.appendChild(createServiceCardDOM(service, false))); }
        }

        if(batalContent) {
            batalContent.innerHTML = '<p class="text-center no-batal-history" style="display:none; color: #6B7280; margin-top: 1rem;">Tidak ada riwayat servis dibatalkan.</p>';
            const canceledServices = serviceHistory.filter(s => s.vehicleId === vehicle.id && s.status === 'Batal');
            const noBatalMsg = batalContent.querySelector('.no-batal-history');
            if (canceledServices.length === 0) { if(noBatalMsg) noBatalMsg.style.display = 'block'; }
            else { if(noBatalMsg) noBatalMsg.style.display = 'none'; canceledServices.forEach(service => batalContent.appendChild(createServiceCardDOM(service, false))); }
        }
        
        const tabButtonToActivate = document.querySelector(`#page-content-container .tab-button[data-tab-target="${initialTab}HistoryContent"]`);
        if (tabButtonToActivate) tabButtonToActivate.click();
         else { const firstTabButton = document.querySelector('#page-content-container .tab-button'); if(firstTabButton) firstTabButton.click(); }
    }

    function createServiceCardDOM(service, showCancelButton) {
        const card = document.createElement('div'); card.className = 'service-card';
        const vehicleForService = vehicles.find(v => v.id === service.vehicleId); 
        card.innerHTML = `
            <div class="service-card-header">
                <img src="${vehicleForService?.image || 'https://placehold.co/64x40/A93C3C/FFFFFF?text=Mobil'}" alt="${service.vehicleName}" onerror="this.src='https://placehold.co/64x40/A93C3C/FFFFFF?text=Mobil'">
                <div class="service-card-details">
                    <h4>${service.vehicleName} (${service.license})</h4>
                    <p>Tanggal: ${service.date} ${service.time || ''}</p><p>Jenis Servis: ${service.type}</p><p>Biaya: ${service.cost}</p>
                    <p>Status: <span class="status-${service.status.toLowerCase()}">${service.status}</span></p>
                    ${service.status !== 'Booked' && service.status !== 'Batal' ? `<p>Invoice: ${service.invoice}</p><p>Lokasi: ${service.location}</p><p>Mekanik: ${service.mechanic}</p>` : ''}
                </div>
            </div>
            ${showCancelButton && service.status === 'Booked' ? `<button class="btn btn-danger btn-block cancel-booking-btn" data-service-id="${service.id}">Cancel Booking</button>` : ''}
            ${(service.status === 'Selesai' || service.status === 'Batal') ? `<button class="btn btn-primary btn-block service-again-btn" data-vehicle-id="${service.vehicleId}" data-service-type="${service.type}">SERVIS LAGI</button>` : ''}`;
        
        if (showCancelButton && service.status === 'Booked') {
            const cancelButton = card.querySelector('.cancel-booking-btn');
            if(cancelButton) {
                cancelButton.onclick = () => { 
                    const serviceToUpdate = serviceHistory.find(s => s.id === service.id);
                    if (serviceToUpdate) { serviceToUpdate.status = 'Batal'; showCustomAlert('Servis berhasil dibatalkan.', 'info'); loadPage('status-booking-cancel', 'Status'); }
                };
            }
        }
        const serviceAgainButton = card.querySelector('.service-again-btn');
        if (serviceAgainButton) {
            serviceAgainButton.onclick = (e) => { 
                const vehicleId = parseInt(e.currentTarget.dataset.vehicleId); const serviceType = e.currentTarget.dataset.serviceType;
                const vehicle = vehicles.find(v => v.id === vehicleId);
                if (vehicle) {
                    currentVehicleForBooking = vehicle; loadPage('book-service-form', 'Detail Servis');
                    setTimeout(() => { const typeSelect = document.getElementById('bookingServiceType'); if(typeSelect) typeSelect.value = serviceType; }, 0);
                }
            };
        }
        return card;
    }
    
    function bindStatusDoneButton() {
        document.querySelectorAll('.status-done-btn').forEach(button => {
            button.onclick = () => { 
                const pageId = button.dataset.pageIdToLoad; const title = button.dataset.title; const initialTab = button.dataset.initialTab;
                loadPage(pageId, title, { initialTab });
            };
        });
    }

    function renderInfoTipsPage() {
        const searchInput = document.getElementById('infoTipsSearchInput');
        if (searchInput) {
            searchInput.onkeyup = () => {
                displayFilteredTips(searchInput.value);
            };
        } else {
            console.error("Search input 'infoTipsSearchInput' not found on page load.");
        }
        displayFilteredTips(''); // Initial render of all tips
    }

    function displayFilteredTips(searchTerm) {
        const listContainer = document.querySelector('#page-content-container .info-tips-list');
        const noTipsMsgElement = document.querySelector('#page-content-container .no-tips-message');

        if (!listContainer || !noTipsMsgElement) {
            // console.warn("Info tips DOM elements not found. Page might not be fully loaded or elements are missing.");
            return; 
        }
        
        listContainer.innerHTML = ''; // Clear previous tips
        const normalizedSearchTerm = searchTerm.toLowerCase().trim();

        const filteredTips = tips.filter(tip => {
            return tip.title.toLowerCase().includes(normalizedSearchTerm) ||
                   tip.snippet.toLowerCase().includes(normalizedSearchTerm) ||
                   tip.content.toLowerCase().includes(normalizedSearchTerm);
        });

        if (tips.length === 0) {
            noTipsMsgElement.textContent = 'Tidak ada informasi atau tips untuk ditampilkan.';
            noTipsMsgElement.style.display = 'block';
        } else if (filteredTips.length === 0 && normalizedSearchTerm) { 
            noTipsMsgElement.textContent = `Tidak ada hasil yang cocok dengan "${searchTerm}".`;
            noTipsMsgElement.style.display = 'block';
        } else if (filteredTips.length === 0 && !normalizedSearchTerm) { 
            noTipsMsgElement.textContent = 'Tidak ada informasi atau tips untuk ditampilkan.';
            noTipsMsgElement.style.display = 'block';
        }
        else { 
            noTipsMsgElement.style.display = 'none';
            filteredTips.forEach(tip => {
                const card = document.createElement('div'); card.className = 'tip-card';
                card.innerHTML = `
                    <img src="${tip.image}" alt="${tip.title}" onerror="this.src='https://placehold.co/96x70/A93C3C/FFFFFF?text=Info'">
                    <div class="tip-card-content"><h4>${tip.title}</h4><p class="snippet">${tip.snippet}</p>
                    <button class="read-more-tip" data-tip-id="${tip.id}">Baca Selengkapnya <i class="fas fa-chevron-down"></i></button>
                    <div class="tip-full-content hidden">${tip.content}</div></div>`;
                
                const readMoreButton = card.querySelector('.read-more-tip');
                if(readMoreButton){
                    readMoreButton.onclick = (e) => { 
                        const contentDiv = e.currentTarget.nextElementSibling; 
                        const icon = e.currentTarget.querySelector('i');
                        if(contentDiv) contentDiv.classList.toggle('hidden'); 
                        if(icon) {
                            icon.classList.toggle('fa-chevron-down'); 
                            icon.classList.toggle('fa-chevron-up');
                        }
                    };
                }
                listContainer.appendChild(card);
            });
        }
    }
    
    function showCustomAlert(message, type = 'info') { 
        alert(`[${type.toUpperCase()}] ${message}`); 
    }

    loadPage('home', 'Beranda'); 
});

